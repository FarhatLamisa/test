<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
        }

        .header {
            overflow: hidden;
            background-color: #fffff;
            padding: 20px 10px;
        }

        .header a {
            float: center;
            color: black;
        }

        .header a:hover {
            background-color: #ddd;
            color: black;
        }

        .header a.active {
            background-color: dodgerblue;
            color: white;
        }

        @media screen and (max-width: 500px) {
            .header a {
                float: none;
                display: block;
                text-align: left;
            }
        }
    </style>
</head>

<body>
<div class="header"> 
			<p> Blog authentication</p>
    </div>
    <div class="header">
        <div class="header-right">
            <a href="userloginpage.php" class="right">LOGIN</a>
        </div>
    </div>
	

</body>

</html>