<?php
session_start();
include 'connection.php';
$result = mysqli_query($conn, "SELECT * FROM bloginfo ORDER BY id DESC");

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog</title>

    <style>
        table {
            padding: 40px;
            text-align: center;
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            border-radius: 2px;
            border-style: solid;
            color: #da2345;

        }

        td {
            padding: 10px;
            margin: 20px 30px;

        }
    </style>
</head>

<body>
    <ul>
        <li><a href="newblog.php">Create</a></li>

    </ul>

    <table width='50%' height='15%' border='0'>

        <tr>
            <td>Title</td>
            <td>Slug</td>
            <td>Description</td>
            <td>Update</td>
            <td>Delete</td>


        </tr>
        <?php

        while ($res = mysqli_fetch_array($result)) {
            echo "<tr>";
            echo "<td>" . $res['title'] . "</td>";
            echo "<td>" . $res['slug'] . "</td>";
            echo "<td>" . $res['description'] . "</td>";
            echo "<td bgcolor='green'><a href=\"edit.php?id=$res[id]\"><font color='white'>Edit</a>";
            echo "<td bgcolor='green'><a href=\"delete.php?id=$res[id]\"><font color='white'>Delete</a>";
        }
        ?>
    </table>


</body>

</html>