<?php

include_once("connection.php");

if (isset($_POST['update'])) {
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $slug = mysqli_real_escape_string($conn, $_POST['slug']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
	
    if (empty($title) || empty($slug) || empty($description)) {

        if (empty($title)) {
            echo "<font color='red'>Title field is empty.</font><br/>";
        }

        if (empty($slug)) {
            echo "<font color='red'>Slug field is empty.</font><br/>";
        }

        if (empty($description)) {
            echo "<font color='red'>Description field is empty.</font><br/>";
        }
    } else {

        $result = mysqli_query($conn, "update bloginfo set title='$title',slug='$slug',description='$description'");


        header("Location: bloginfo.php");
    }
}
?>
<?php

$id = $_GET['id'];

$result = mysqli_query($conn, "SELECT * FROM bloginfo WHERE id=$id");

while ($res = mysqli_fetch_array($result)) {
    $title  = $res['title'];
    $slug = $res['slug'];
    $description = $res['description'];
}
?>
<html>

<head>
    <title>Edit Data</title>
</head>

<body>
    <form name="form1" method="post" action="edit.php">
        <table border="0">

            <tr>
                <td>Title</td>
                <td><input type="text" name="title" value="<?php echo $title; ?>"></td>
            </tr>
            <tr>
                <td>Slug</td>
                <td><input type="urldecode" name="slug" value="<?php echo $slug; ?>"></td>
            </tr>

            <tr>
                <td>Description</td>
                <td><input type="text" name="description" value="<?php echo $description; ?>"></td>
            </tr>
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id']; ?>></td>
                <td><input type="submit" name="update" value="Update"></td>
            </tr>






        </table>
    </form>
</body>

</html>