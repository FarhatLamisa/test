<?php

include_once("connection.php");

if (isset($_POST['delete'])) {

    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $title = mysqli_real_escape_string($conn, $_POST['title']);
    $slug = mysqli_real_escape_string($conn, $_POST['slug']);

    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $result = mysqli_query($conn, "delete from bloginfo where id=$id");

    header("Location: bloglist.php");
}
?>
<?php

$id = $_GET['id'];

$result = mysqli_query($conn, "SELECT * FROM bloginfo WHERE id=$id");

while ($res = mysqli_fetch_array($result)) {
    $title  = $res['title'];
    $slug = $res['slug'];
    $description = $res['description'];
}
?>
<html>

<head>
    <title>Delete Data</title>
</head>

<body>
    <form name="form1" method="post" action="delete.php">
        <table border="0">
            <tr>
                <td>Title</td>
                <td><input type="text" name="title" value="<?php echo $title; ?>"></td>
            </tr>

            <tr>
                <td>Slug</td>
                <td><input type="text" name="slug" value="<?php echo $slug; ?>"></td>
            </tr>

            <tr>
                <td>Description</td>
                <td><input type="text" name="description" value="<?php echo $description; ?>"></td>
            </tr>
			
            <tr>
                <td><input type="hidden" name="id" value=<?php echo $_GET['id']; ?>></td>
                <td><input type="submit" name="delete" value="Delete"></td>
            </tr>
        </table>
    </form>
</body>

</html>