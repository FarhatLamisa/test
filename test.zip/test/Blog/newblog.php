<?php
require_once('connection.php');
if (isset($_REQUEST["submit"])) {
	$title = $_POST['title'];
	$slug = $_POST['slug'];
	$description = $_POST['description'];

        $_result = mysqli_query($conn, $q);
        $num = mysqli_num_rows($_result);

        $que = "insert into bloginfo(title,slug,description) values('$title','$slug','$description')";




            mysqli_query($conn, $que);

            header('location:bloglist.php');
          
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
<script>
function convertToSlug(Text)
{
    return Text
        .toLowerCase()
        .replace(/ /g,'-')
        .replace(/[^\w-]+/g,'')
        ;
}
</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>
        form {
            text-align: center;
        }

        input {
            margin: 5px 5px;
            padding: 5px;
        }
    </style>
</head>

<body>
    <form enctype="multipart/form-data" method="post">


        <label>Title</label>
        <input type="text" name="title" class="userinput"></br>
		<label>Slug</label>
        <input type="text" name="slug" class="userinput"></br>
		<label>Description</label>
        <input type="text" name="description" class="userinput"></br>
        <input type="submit" name="submit" value="upload">

    </form>
</body>

</html>