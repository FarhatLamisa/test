<?php
$a = 5;
$b = 10;
echo "\nBefore exchanging:  a=". $a . ',b=' . $b;
echo "</br>";  
list($a, $b) = array($b, $a);
echo "\nAfter exchanging:  a=". $a . ',b=' . $b;
echo "</br>";  
?>