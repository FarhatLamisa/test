<?php
//$N = (int)readline();
//echo $N
$N=5;
for ( $i=1; $i<=$N; $i++) {
        for ($space=1; $space<=($N-$i); $space++){
                echo " ";
        }
        for ($hash=1; $hash<=$i; $hash++){
                echo "#";
        }
        echo "</br>";
}
?>